# CS147DVParser

This package is used to quickyl convert CS147DV instructions into hexadecimal. This only works with the 2019-2020 version of the ISA. 

The program was originally written by Jordan Conragan in the fall semester of 2019. Rick Deamicis created a Python implementation for the Fall 2020 version of the course.
Pull requests are encouraged. 

# How to use
The Java implemention of the program and instructions can be found in the CS147DVJavaParser folder.

The Python implementation and instructions can be found in CS147DVPyParser
